<?php

/**
 * Navaluzer Group - NavPedia SMM
 * 
 * @package SMM
 * @category SSP / Class / OOP / Authentication
 * @author Navaluzer Group <contact@nav-pedia.co.id>
 * @version BETA v0.1
 * @copyright Navaluzer Group Inc.
 * 
 *
 * 
 * 
  */
require_once __DIR__.'\..\config\mainconfig.php';

class auth extends connection
{
    /*
    |--------------------------------------------------------------------------
    | Variabel Login
    |--------------------------------------------------------------------------
    |
    | Variabel khusus untuk fungsi login
    | 
    | 
    |
    */

    var $username;
    var $password;
    var $csrf_token;

    /**
     * Fungsi Login
     * 
     * @return  array
      */
    function login()
    {
        
        global $_POST;

        /*
        |--------------------------------------------------------------------------
        | Send Request Data
        |--------------------------------------------------------------------------
        |
        | Mengirim permintaan data login pengguna
        | 
        | 
        |
        */

        $username   = $this->uname   = htmlspecialchars($_POST['username']);
        $password   = $this->pw   = $_POST['password'];
        $csrf_token = $this->csrf_token = $_POST['csrf_token'];
        $user_ip    = $this->server("remote_addr");
        $isMobile   = ($this->isMobile() == true ? "Mobile" : "Desktop");
        // var $saveLogin  = $_POST['remember'];
        $dateNow    = date("d/m/Y H:i:s");
        
        /*
        |--------------------------------------------------------------------------
        | MySqli pengguna
        |--------------------------------------------------------------------------
        |
        | Mengambil data pengguna di database
        | 
        | 
        |
        */

        $userSQL    = "SELECT * FROM users WHERE username = '$username' ";
        $userQuery  = $this->conn->query($userSQL);
        $userData   = mysqli_fetch_assoc($userQuery);

        /**
         * Memulai proses login
         * 
         * @return array
          */
        if(empty($username) || empty($password))
        {
            // Kedua data kosong
            $result = 
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Masih ada data yang kosong",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else if(empty($username))
        {
            // Username / Nama Pengguna tidak di isi.
            $result =
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Nama pengguna tidak boleh kosong",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else if(empty($password))
        {
            // Password tidak di isi.
            $result =
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Nama pengguna tidak boleh kosong",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else if(mysqli_num_rows($userQuery) == 0)
        {
            // Pengguna tidak ditemukan.
            $result =
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Pengguna tidak terdaftar",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else if($userData['password'] <> $password)
        {
            // Kata sandi tidak sesuai / salah
            $result =
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Kata sandi salah",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else if($userData['status'] != "active")
        {
            // Validasi status
            $levelCheck = $this->levelCheck($userData['status']);
            $result = 
            [
                "response"  => $levelCheck['response'],
                "action"    => $levelCheck['action'],
                "pesan"     => $levelCheck['pesan'],
                "ip"        => $user_ip,
                "raw"       => 0
            ];

        } else if($this->validationToken() != true)
        {
            // Gagal melakukan validasi CSRF_TOKEN
            $result =
            [
                "response"  => false,
                "action"    => "login",
                "pesan"     => "Invalid csrf_token",
                "ip"        => $user_ip,
                "raw_id"    => 0
            ];

        } else
        {
            /**
             * Melanjutkan proses login berupa
             * 
             * Mencatat login.
             * Memberikan hak akses.
             * etc
              */

            // Insert Activities
            $LoginSQL   = "INSERT INTO `aktivitas` (`id`, `user`, `jenis`, `pesan`, `ip`, `perangkat`, `tanggal`) VALUES (NULL, '$username', 'lOGIN_WEB', 'Selamat Datang ^_^', '$user_ip', '$isMobile', CURRENT_TIMESTAMP)";
            $RunSQL     = $this->conn->query($LoginSQL);

            if($RunSQL == true)
            {
                // Berhasil Login
                $result = 
                [
                    "response"      => true,
                    "action"        => "login",
                    "pesan"         => "Selamat Datang!",
                    "username"      => $username,
                    "login_date"    => $dateNow,
                    "device"        => $isMobile,
                    "ip"            => $user_ip,
                ];

            } else if($RunSQL == false)
            {
                // Gagal Login
                $result =
                [
                    "response"  => false,
                    "action"    => "login",
                    "pesan"     => "failed to login #activities",
                    "ip"        => $user_ip,
                    "raw_id"    => 0
                ];

            }
        }
        $encode = json_encode($result);
        return $encode;
        die();
        

    }

    public function register()
    {
        /* ... */
    }

    /*
    |--------------------------------------------------------------------------
    | Logout Variabel
    |--------------------------------------------------------------------------
    |
    | ...
    | 
    | 
    |
    */

    protected $logout;

    /**
     * Logout Function
      */
    public function logout()
    {
        /* Run Logout Function */
        $this->logout = session_destroy();
        return $this->logout;
    }

    public function levelCheck($request)
    {
        /*
        |--------------------------------------------------------------------------
        | Variabel level check
        |--------------------------------------------------------------------------
        |
        | ....
        | 
        | 
        |
        */

        $user_ip = $this->server("remote_addr");

        /**
         * Proses pengecekan level pengguna
         * 
         * @return boolean
          */
        if($request == "suspend")
        {
            // Suspend result
            return $result = array(
                "response"  => false,
                "action"    => "levelCheck",
                "pesan"     => "Akun anda di suspend.",
                "ip"        => $user_ip,
                "raw_id"    => 0
            );

        } else if($request == "warning")
        {
            // Warning result
            return $result = array(
                "response"  => false,
                "action"    => "levelCheck",
                "pesan"     => "Akun anda mendapat peringatan, harap melapor ke bantuan pengguna.",
                "ip"        => $user_ip,
                "raw_id"    => 0
            );

        } else if($request == "locked")
        {
            // Locked result
            return $result = array(
                "response"  => false,
                "action"    => "levelCheck",
                "pesan"     => "Akun anda di dikunci untuk alasan keamanan.",
                "ip"        => $user_ip,
                "raw_id"    => 0
            );
            
        } else
        {
            return true;
        }
    }


}