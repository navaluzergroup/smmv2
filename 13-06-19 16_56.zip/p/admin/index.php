<?php

require_once $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/manager/resource/header.php';
