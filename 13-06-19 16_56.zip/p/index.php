<?php
header("Location: /");